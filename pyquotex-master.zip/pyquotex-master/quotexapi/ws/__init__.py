# quotexapi/ws/__init__.py

"""Module for Quotex API websocket."""
