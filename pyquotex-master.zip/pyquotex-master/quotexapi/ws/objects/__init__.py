# quotexapi/ws/objects/__init__.py

