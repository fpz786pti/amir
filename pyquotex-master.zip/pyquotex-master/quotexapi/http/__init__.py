# quotexapi/http/__init__.py

"""Module for Quotex API http."""
