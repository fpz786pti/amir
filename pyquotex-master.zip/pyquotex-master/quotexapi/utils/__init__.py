# quotexapi/utils/__init__.py

"""Module for Quotex API playwright."""
